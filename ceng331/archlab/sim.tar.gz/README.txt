Hi hi! The pre-checking scripts I used that generated your 'log.txt' outputs
are here. You need to run them with a fresh 'sim' directory extracted from
the homework's sim.tar and a directory containing your part submission files
as arguments. Example directories with empty files are provided under 'example' 
along with a fresh sim. Here's an example for pre-checking part a (make sure
to compile 'sim' first using 'make'!):
$ cd examples
$ ../parts/part-a/grade_yis.sh parta-submission sim

I wrote the pre-checkers in bash and used them locally, but they should
work on the ineks as well.

Of course, the grading has a significant manual component as well. So make sure to read your feedbacks! 

- Deniz
