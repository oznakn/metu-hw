#! /bin/bash

test_results() {
  # a helper called by the others
  # test_results nsucceeded ntotal failfile log
  local ret=0
  printf "Passed $1/$2 tests." >> "$4"
  if [[ $1 != $2 ]]; then
    printf " Failed tests:\n" >> "$4"
    cat "$3" >> "$4"
    ret=1
  else
    printf " Success!\n" >> "$4"
  fi
  rm -f "$3"
  return $ret
}


test_sim_y86() {
  # common function for testssim & psim
  # test_sim_y86 make-arg log-file
  local tmpfile=$(mktemp)
  local failfile=$(mktemp)
  (cd ../y86-code && make "$1") > "$tmpfile"
  # check to see if any test fails
  local num_failed=$(grep 'Check Fails' "$tmpfile" | tee "$failfile" | wc -l)
  local num_succeeded=$(grep 'Check Succeeds' "$tmpfile" | wc -l)
  local num_total=$(($num_failed + $num_succeeded))
  rm -f "$tmpfile"
  test_results $num_succeeded $num_total "$failfile" "$2"
}

test_ptest() {
  # common function for ptest
  # test_ptest sim_path tflags log
  local tmpfile=$(mktemp)
  (cd ../ptest && make "SIM=$1" "TFLAGS=$2") > "$tmpfile"
  # count all checks, really pretty annoying due to the format
  # I should really learn some more text processing...
  # # All N ISA Checks Succeeed
  # # X/N ISA Checks Failed
  local num_total=$(grep 'Checks Succeed' "$tmpfile" | awk '{ s += $2; } END { print s; }')
  local tmp2=$(mktemp)
  grep 'Checks Failed' "$tmpfile" | awk '{ print $1; }' > "$tmp2"
  local num_failed=0
  if [ -s "$tmp2" ]; then  # some checks failed, time to count 'em
    local x_total=$(sed 's/.*\/\([0-9]\+\)/\1/' "$tmp2" | awk '{ s += $1; } END { print s; }')
    num_total=$(($num_total+$x_total))
    num_failed=$(sed 's/\([0-9]\+\)\/.*/\1/' "$tmp2" | awk '{ s += $1; } END { print s; }')
  fi
  local num_succeeded=$(($num_total-$num_failed))
  # write the fail output to tmp2
  grep "failed" "$tmpfile" > "$tmp2"
  mv "$tmp2" "$tmpfile"
  # Finally, call the test output
  test_results $num_succeeded $num_total "$tmpfile" "$3"
} 
