#! /bin/bash

BASE_GRADE=10 # modify if computation description is missing
SSIM_GRADE=10 # grade for passing the basic test ssim tests
INST_GRADE=15 # grade for passing the regression tests including the new instruction

# get rid of annoying , decimal sep
LC_NUMERIC="en_US.UTF-8" 

if [ "$#" != 2 ]; then
  echo "usage: ./grade_seq.sh partb_folder sim_folder"
  exit
fi

# source the common library
LIB="$(dirname $0)/../library.sh"
source "$LIB"

test_ssim() {
  # log file is the only arg
  test_sim_y86 testssim "$1"
}

test_regression() {
  # log file is the only arg
  test_ptest "../seq/ssim" "-j" "$1"
}

seq_folder="$2/seq"
LOG=$(realpath "$1/log.txt") # get the full path, since we'll cd to seq
seq_full="$1/seq-full.hcl"

rm -f "$LOG"
grade=0
if [ -e "$seq_full" ]; then
  # file exists! put seq-full.hcl inside seq and compile
  errfile=$(mktemp)
  cp "$seq_full" "$seq_folder"
  cd "$seq_folder"
  if make clean &>/dev/null && make >/dev/null 2>"$errfile"; then
    # make succeeded! so far so good.
    printf "Compilation succeeded.\nTest on y86-code: " >> "$LOG"
    if test_ssim "$LOG"; then
      # make testssim on y86-code succeeded! nothing broken.
      grade=$(($grade + $SSIM_GRADE))
      printf "Regression tests (inc. -j): " >> "$LOG"
      if test_regression "$LOG"; then
        # regression tests succeeded! nice.
        grade=$(($grade + $INST_GRADE))
      fi 
    fi
  else
    echo "Compilation failed:" >> "$LOG"
    cat "$errfile" >> "$LOG"
  fi
  rm -f "$errfile"
else
  echo "seq-full.hcl not found in the submission directory." >> "$LOG"
fi

printf "\nPrecheck grade: %.2f (+%s possible from computation descr.)\n" "$grade" "$BASE_GRADE" >> "$LOG"
# output the final grade
echo "$grade"
