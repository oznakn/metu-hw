#! /bin/bash

# get rid of annoying , decimal sep
LC_NUMERIC="en_US.UTF-8" 

if [ "$#" != 2 ]; then
  echo "usage: ./grade_pipe.sh partc_folder sim_folder"
  exit
fi

YES="Yes"
NO="No"

BASE_GRADE=40 # to be validated through the comments
PERF_THRESH="7.49"
PERFPP_THRESH="7.39"

BASE_BENCHMARKS=10
FULL_BENCHMARKS=100

# source the common library
LIB="$(dirname $0)/../library.sh"
source "$LIB"

test_psim() {
  # log file is the only arg
  test_sim_y86 testpsim "$1"
}

test_regression() {
  # log file is the only arg
  test_ptest "../pipe/psim" "" "$1"
}

test_with_jmpq() {
  test_ptest "../pipe/psim" "-j" "$1"
}

build_and_check_pipe() {
  local errfile=$1
  local log=$2
  if make clean &>/dev/null && make >/dev/null 2>"$errfile"; then
    # make succeeded! so far so good.
    printf "Compilation succeeded.\nTest on y86-code: " >> "$log"
    if test_psim "$log"; then
      # make testpsim on y86-code succeeded! nothing broken.
      printf "Regression tests: " >> "$log"
      if test_regression "$log"; then
        return 0
      fi 
    fi
  else
    echo "Compilation failed:" >> "$log"
    cat "$errfile" >> "$log"
  fi
  return 1
}

correctness_check() {
  # log is the only argument
  local passed total
  local tmpfile=$(mktemp)
  ./correctness.pl -p > "$tmpfile"
  IFS=/ read passed total < <(tail -1 "$tmpfile" | awk '{ print $1; }')
  # write out the failed tests for logging
  local tmp2=$(mktemp)
  grep -E '^[0-9]+\s' "$tmpfile" | grep -v OK > "$tmp2"
  mv "$tmp2" "$tmpfile"
  printf "Correctness on PIPE: " >> "$1"
  test_results $passed $total "$tmpfile" "$1"
}

benchmark_once() {
  # log is the only argument again
  local tmpfile=$(mktemp)
  ./benchmark.pl > "$tmpfile"
  local avg_cpe=$(grep 'Average CPE' "$tmpfile" | awk '{ print $3; }')
  local score dummy
  IFS=/ read score dummy < <(grep 'Score' "$tmpfile" | awk '{ print $2; }')
  # printf "Benchmarked %.2f average CPE for %.1f points.\n" "$avg_cpe" "$score" >> "$1"
  echo "$avg_cpe" "$score"
}

benchmark() {
  local avg_cpe perf_score tmp_cpe tmp_score run_full
  
  # initial benchmarks to check similarity
  read avg_cpe perf_score < <(benchmark_once)
  for i in $(seq 2 $BASE_BENCHMARKS); do
    read tmp_cpe tmp_score < <(benchmark_once)
    if [[ "$tmp_cpe" != "$avg_cpe" ]]; then
      echo "Differing CPE detected during first $BASE_BENCHMARKS runs, in $i runs." >> "$1"
      echo "Running $FULL_BENCHMARKS benchmarks and getting minimum:" >> "$1"
      run_full=1
      break
    fi
  done

  # full benchmarks if necessary
  if [[ -n "$run_full" ]]; then
    for i in $(seq 1 $FULL_BENCHMARKS); do
      read tmp_cpe tmp_score < <(benchmark_once)
      if [[ $(bc <<< "$tmp_cpe < $avg_cpe") == 1 ]]; then
        avg_cpe="$tmp_cpe"
        perf_score="$tmp_score"
      fi
    done
  fi

  echo "$avg_cpe" "$perf_score"
}

generic_perf_bonus_check() {
  # perf_check avg-cpe thresh bonus-name log
  if [[ $(bc <<< "$1 <= $2") == 1 ]]; then
    echo "CPE <= $2, $3 bonus granted." >> "$4"
    return 0
  fi
  echo "CPE > $2, $3 bonus NOT granted." >> "$4"
  return 1
}
        
perf_bonus_check() {
  generic_perf_bonus_check $1 $PERF_THRESH "Performance" "$2"
}

perfpp_bonus_check() {
  generic_perf_bonus_check $1 $PERFPP_THRESH "Performance++" "$2"
}

jsimple_cycle_check() {
  local tmpfile=$(mktemp)
  ./psim -t ../y86-code/jsimple.yo > "$tmpfile"
  local ret=1
  printf "Checking jsimple.yo: " >> "$1"
  if grep 'ISA Check Succeeds' "$tmpfile" &>/dev/null &&
     grep 'CPI: 5 cycles/5 instructions = 1.00' "$tmpfile" &>/dev/null; then
    # jsimple runs in five cycles! nice
    echo "ran in 5 cycles. Success!" >> "$1"
    ret=0
  else
    echo "failed to run in 5 cycles. Failed:" >> $1
    tail -2 "$tmpfile" >> "$1"
  fi
  rm -f "$tmpfile"
  return $ret
}

jmpq_bonus_check() {
  # finally, check jmpq
  printf "Checking JMPQ for the bonus (regression with -j): " >> "$1"
  if test_with_jmpq "$1" && jsimple_cycle_check "$1"; then
    echo "All tests passed, jmpq on PIPE bonus granted." >> "$1"
    return 0
  fi
  echo "JMPQ tests failed, jmpq on PIPE bonus NOT granted." >> "$1"
  return 1
}

pipe_folder="$2/pipe"
LOG=$(realpath "$1/log.txt") # get the full path, since we'll cd to pipe
pipe_full="$1/pipe-full.hcl"
ncopy="$1/ncopy.ys"

# clear the log & init grade & bonuses
rm -f "$LOG"
grade=0
avg_cpe="0.00"
perf=$NO
perfpp=$NO
jmpq_on_pipe=$NO
# pretty similar to the part-b grader at first
# while building & testing psim instead of ssim
if [ -e "$ncopy" ]; then
  if [ -e "$pipe_full" ]; then
    # file exists! put pipe-full.hcl inside pipe and compile
    errfile=$(mktemp)
    cp "$ncopy" "$pipe_folder"
    cp "$pipe_full" "$pipe_folder"
    cd "$pipe_folder"
    if build_and_check_pipe "$errfile" "$LOG"; then
      # psim is now built and has been checked against the base.
      # now, time to check the correctness of the code against PIPE
      if correctness_check "$LOG"; then
        # benchmark and update the grade
        read avg_cpe perf_score < <(benchmark "$LOG")
        grade=$(bc <<< "$grade + $perf_score")
        printf "Benchmarked %.2f average CPE for %.1f points.\n" "$avg_cpe" "$perf_score" >> "$LOG"
        # check the bonuses
        printf "\nBonus checks:\n" >> "$LOG"
        if perf_bonus_check $avg_cpe "$LOG"; then
          perf=$YES
        fi
        if perfpp_bonus_check $avg_cpe "$LOG"; then
          perfpp=$YES
        fi
        if jmpq_bonus_check "$LOG"; then
          jmpq_on_pipe=$YES
        fi
      fi
    fi
    rm -f "$errfile"
  else
    echo "pipe-full.hcl not found in the submission directory." >> "$LOG"
  fi
else
  echo "ncopy.ys not found in the submission directory." >> "$LOG"
fi

printf "\nPrecheck grade: %.2f (+%s possible from comments)\n" "$grade" "$BASE_GRADE" >> "$LOG"

# output the final grade
echo "$grade"
echo "$perf"
echo "$perfpp"
echo "$jmpq_on_pipe"
echo "$avg_cpe"
