#! /bin/bash

GRADE_PER_PART=10

# get rid of annoying , decimal sep
LC_NUMERIC="en_US.UTF-8" 

# path of the expected folder, relative to the script
DIR=$(dirname "$0")
EXP_FOLDER="$DIR/expected"

if [ "$#" != 2 ]; then
  echo "usage: ./grade_yis.sh parta_folder sim_folder"
  exit
fi

split_yis_output() {
  csplit --suppress-matched <(tail -n+2 "$1") '/^$/' '{*}' > /dev/null
  mv xx00 "$outfile".reg
  mv xx01 "$outfile".mem
}

split_expected() {
  # split the expectation file and print the file name
  # could be cached between evaluations, but not really worth it
  csplit --suppress-matched "$1" '/^$/' '{*}' > /dev/null
  local fname=$(cat xx00)
  rm xx00
  mv xx01 "$fname".regtarget
  mv xx02 "$fname".memtarget
  mv xx03 "$fname".memforbid
  echo "$fname"
}

clean_expected() {
  rm -f *.regtarget *.memtarget *.memforbid
}

check_contained() {
  # check if a file is contained in another one (line-by-line)
  # check_contained check-name file-to-compare target-file log-file
  if [[ $(comm -13 <(sort -u "$2") <(sort -u "$3")) ]]; then
    printf "%s check failed:\n" "$1" >> "$4"
    cat "$2" >> "$LOG"
    return 1
  else
    printf "%s check succeeded.\n" "$1" >> "$4"
    return 0
  fi
}

build_grep_disjunction() {
  # take a file, and return a grep string searching for
  # any of the lines, pretty crude but it does the job
  # assuming that the lines do not contain any spaces
  local ord=$(cat "$1" | head --bytes=-1 | tr '\n' ' ' | sed 's/ /\\|/g')
  # ^ trim the last extra newline, replace '\n' with ' ', replace ' ' with '\|'
  # finally wrap in pars to get a proper regex disjunction for grep
  echo "\($ord\)"
}


yas="$2/misc/yas"
yis="$2/misc/yis"
parta_folder="$1"
LOG="$parta_folder/log.txt"

rm -f "$LOG"
errfile=$(mktemp)
tmpfile=$(mktemp)
grade=0
for expfile in "$EXP_FOLDER"/*; do
  # split the output files
  # check and compile the file
  fname=$(split_expected "$expfile")
  fpath="$parta_folder/$fname"
  printf "Checking %s...\n" "$fname" >> "$LOG"
  if [ -e "$fpath" ]; then
    if "$yas" "$fpath" >/dev/null 2>"$errfile"; then
      echo "YAS assembly succeeded." >> "$LOG"
      # file assembled, simulate it
      objpath=${fpath%.ys}.yo
      outfile="$parta_folder/$fname.out"
      "$yis" "$objpath" >"$outfile" 2>"$errfile"
      # split output into reg & mem
      split_yis_output "$outfile"
      # now, compare the register & memory values
      if check_contained "Register" "$outfile.reg" "$fname.regtarget" "$LOG" &&\
         check_contained "Memory" "$outfile.mem" "$fname.memtarget" "$LOG"; then
        # finally, check for memory corruption
        if ! grep "$(build_grep_disjunction "$fname.memforbid"):" \
           "$outfile.mem" > "$errfile"; then
          echo "Corruption check succeeded." >> "$LOG"
          grade=$((grade+$GRADE_PER_PART))
        else
          echo "Memory corruption detected:" >> "$LOG"
          cat "$errfile" >> "$LOG"
        fi
      fi
    else
      echo "YAS assembly failed:" >> "$LOG"
      cat "$errfile" >> "$LOG"
    fi
  else
    printf "File %s does not exist in the submission directory.\n" "$fname" >> "$LOG"
  fi
  echo >> "$LOG"
  clean_expected
done

rm -f "$errfile" "$outfile"

printf "\nPrecheck grade: %.2f\n" "$grade" >> "$LOG"
# print the tentative part A grade
echo $grade
