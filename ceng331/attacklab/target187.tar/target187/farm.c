/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_183()
{
    return 3284699464U;
}

void setval_442(unsigned *p)
{
    *p = 3247007908U;
}

unsigned getval_153()
{
    return 3286206792U;
}

void setval_277(unsigned *p)
{
    *p = 2425394265U;
}

unsigned addval_371(unsigned x)
{
    return x + 3284568392U;
}

unsigned getval_474()
{
    return 2425510262U;
}

void setval_389(unsigned *p)
{
    *p = 3287521608U;
}

void setval_321(unsigned *p)
{
    *p = 3284283720U;
}

unsigned addval_107(unsigned x)
{
    return x + 2915274841U;
}

unsigned getval_323()
{
    return 3049478460U;
}

unsigned addval_163(unsigned x)
{
    return x + 3284240712U;
}

unsigned addval_447(unsigned x)
{
    return x + 2428930376U;
}

unsigned addval_267(unsigned x)
{
    return x + 3284572488U;
}

void setval_425(unsigned *p)
{
    *p = 3286206792U;
}

unsigned addval_460(unsigned x)
{
    return x + 3267791176U;
}

unsigned getval_145()
{
    return 2431879432U;
}

void setval_459(unsigned *p)
{
    *p = 3284699496U;
}

void setval_273(unsigned *p)
{
    *p = 4085860431U;
}

void setval_357(unsigned *p)
{
    *p = 3286206920U;
}

void setval_355(unsigned *p)
{
    *p = 3287517512U;
}

unsigned addval_264(unsigned x)
{
    return x + 3269429576U;
}

unsigned getval_113()
{
    return 2429061448U;
}

void setval_472(unsigned *p)
{
    *p = 2428645736U;
}

unsigned addval_453(unsigned x)
{
    return x + 2462157128U;
}

unsigned getval_276()
{
    return 2495754568U;
}

void setval_130(unsigned *p)
{
    *p = 3258009727U;
}

void setval_111(unsigned *p)
{
    *p = 3284699496U;
}

unsigned getval_424()
{
    return 3246999630U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
